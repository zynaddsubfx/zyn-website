Here you can find information about how ZynAddSubFX started (diagrams, manuscripts, sounds, first versions).
This is useful if you are curious about the very early history of ZynAddSubFX.

Paul Nasca
http://www.paulnasca.com
http://zynaddsubfx.sourceforge.net

