Implementation of PADsynth algorithm.
The algorithm and the implementation released under Public Domain by Nasca O. Paul.
This files was tested only under Linux, but I think that is very easy to be used into other operating systems.

Subdirectories:
c_basic		- implementation of the basic PADsynth algorithm
c_extended	- implementation of the extended PADsynth algorithm
c_simple_choir	- simple choir generator (it generates multiple samples)
fftwrapper	- a wrapper to the FFTW library (used only by c_* implementations)

PADsynth_CPP	- ready-to-use C++ class. Use a IFFT routine and it's ready to be used into your projects or products

Hope you'll like and use'll it ;)
Paul
