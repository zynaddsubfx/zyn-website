This archive contains many unsorted instruments.
Many are just some tests and most time, the instruments are saved as "master settings" (xmz).
Most of instruments contains a big amount of reverberation (I like long reverb).
Paul