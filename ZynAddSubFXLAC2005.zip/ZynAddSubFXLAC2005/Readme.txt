Name: Nasca Octavian PAUL
Email: zynaddsubfx_AT_yahoo_D0T_com
I sumbit a proposal for project note.
Title: "ZynAddSubFX - an opensource software synthesizer"
My submision is targeted to users and developers.
I believe that I would need more than 20 minutes, because I make extensive use of sound examples.
I need for the presentation a computer with audio setup and midi keyboard.


COPYRIGHT
Everything in this archive is copyright Nasca Octavian PAUL.
I affirm that I am the only holder of the copyright of the Project note (including images).
Everything from this archive was developed and written by me.
I agree that my project note will be published in the conference proceedings of LAC 2005 (in print and online), on the conference CD. 
