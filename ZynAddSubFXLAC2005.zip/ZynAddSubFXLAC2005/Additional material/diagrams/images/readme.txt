All theese files represents the diagrams of ZynAddSubFX (a software synthesizer written by Nasca O. Paul).

http://zynaddsubfx.sourceforge.net
