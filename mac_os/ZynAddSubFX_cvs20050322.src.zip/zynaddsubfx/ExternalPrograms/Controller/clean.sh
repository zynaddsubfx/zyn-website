rm -f *.o controller ControllerUI.cxx ControllerUI.h 
