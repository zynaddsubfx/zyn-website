rm -f *.o spliter SpliterUI.cxx SpliterUI.h 
