This is a tonemapper for LDR images written by Nasca Octavian PAUL.
e-mail: zynaddsubfx AT yahoo D0T com

Requirements:
    FLTK library (for User Interface), from http://www.fltk.org/
    FreeImage (for loading/saving the images), from http://freeimage.sourceforge.net/
    
